﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="PropertyTools">
//   Copyright (c) 2014 PropertyTools contributors
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System.Reflection;

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("PropertyTools for WPF")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("Copyright (C) PropertyTools contributors 2014.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// The version numbers are updated in the build (see ~/appveyor.yml)
[assembly: AssemblyVersion("0.0.0.0")]
[assembly: AssemblyInformationalVersion("0.0.0.0")]
[assembly: AssemblyFileVersion("0.0.0.0")]