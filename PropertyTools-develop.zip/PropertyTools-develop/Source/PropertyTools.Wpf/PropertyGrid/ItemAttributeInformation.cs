﻿using PropertyTools.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace PropertyTools
{
    public class ItemAttributeInformation
    {
        public Grid Grid { get; set; }

        public PropertyItem Item { get; set; }

        public Tab Tab { get; set; }
    }
}
