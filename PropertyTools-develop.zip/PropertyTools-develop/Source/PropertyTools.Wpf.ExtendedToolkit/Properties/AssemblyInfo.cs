﻿using System.Windows.Markup;

[assembly: XmlnsPrefix("http://propertytools.org/wpf/extended", "ptext")]
[assembly: XmlnsDefinition("http://propertytools.org/wpf/extended", "PropertyTools.Wpf.ExtendedToolkit")]