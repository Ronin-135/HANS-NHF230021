﻿namespace DataGridDemo
{
    public partial class WpfDataGridExample
    {
        public WpfDataGridExample()
        {
            this.InitializeComponent();
        }
    }
}