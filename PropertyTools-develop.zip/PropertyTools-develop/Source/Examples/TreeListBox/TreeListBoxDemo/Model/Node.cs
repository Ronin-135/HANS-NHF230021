﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Node.cs" company="PropertyTools">
//   Copyright (c) 2014 PropertyTools contributors
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace TreeListBoxDemo
{
    public class Node
    {
        public string Name { get; set; }
    }
}