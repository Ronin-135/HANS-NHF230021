﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="TextBlockExPage.xaml.cs" company="PropertyTools">
//   Copyright (c) 2014 PropertyTools contributors
// </copyright>
// <summary>
//   Interaction logic for TextBlockExPage.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace ControlDemos
{
    /// <summary>
    /// Interaction logic for TextBlockExPage.
    /// </summary>
    public partial class TextBlockExPage
    {
        public TextBlockExPage()
        {
            this.InitializeComponent();
        }
    }
}