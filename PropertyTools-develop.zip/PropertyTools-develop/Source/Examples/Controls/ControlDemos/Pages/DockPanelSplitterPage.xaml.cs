﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DockPanelSplitterPage.xaml.cs" company="PropertyTools">
//   Copyright (c) 2014 PropertyTools contributors
// </copyright>
// <summary>
//   Interaction logic for DockPanelSplitterPage.xaml
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace ControlDemos
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for DockPanelSplitterPage.xaml
    /// </summary>
    public partial class DockPanelSplitterPage : Page
    {
        public DockPanelSplitterPage()
        {
            this.InitializeComponent();
        }
    }
}