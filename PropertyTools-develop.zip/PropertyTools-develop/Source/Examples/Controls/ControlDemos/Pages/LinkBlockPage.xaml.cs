﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="LinkBlockPage.xaml.cs" company="PropertyTools">
//   Copyright (c) 2014 PropertyTools contributors
// </copyright>
// <summary>
//   Interaction logic for LinkBlockPage
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace ControlDemos
{
    /// <summary>
    /// Interaction logic for CheckMarkPage
    /// </summary>
    public partial class LinkBlockPage
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LinkBlockPage" /> class.
        /// </summary>
        public LinkBlockPage()
        {
            this.InitializeComponent();
        }
    }
}