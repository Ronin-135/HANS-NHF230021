﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="LocalPropertyItemFactory.cs" company="PropertyTools">
//   Copyright (c) 2014 PropertyTools contributors
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace PropertyGridDemo
{
    using PropertyTools.Wpf;

    public class CustomOperator : PropertyGridOperator
    {
    }
}