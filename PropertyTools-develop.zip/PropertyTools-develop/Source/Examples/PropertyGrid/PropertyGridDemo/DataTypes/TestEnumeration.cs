﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="TestEnumeration.cs" company="PropertyTools">
//   Copyright (c) 2014 PropertyTools contributors
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ExampleLibrary
{
    public enum TestEnumeration { Red, Green, Blue }
}